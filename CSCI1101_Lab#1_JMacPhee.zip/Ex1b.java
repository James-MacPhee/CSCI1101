/* CSCI 1101 - Lab #1 - Ex1b

   This program takes a user inputted number and 
   prints out whether it is a perfect number or not.

   James MacPhee - B00768516 - Jan.16th/2018 */
import java.util.Scanner;
public class Ex1b{
	public static void main(String[] args){
		
      boolean perfect = false;
      Scanner kb = new Scanner(System.in);
      System.out.print("Please input an integer: ");
      int num = kb.nextInt();
      if(num>0){
         perfect = isPerfect(num);
         if(perfect==true) System.out.print("The number "+num+" is a perfect number.");
         else System.out.print("The number "+num+" is NOT a perfect number.");
      }
      else System.out.print("The number "+num+" is NOT a perfect number.");
	}
   //Method to determine whether number is a perfect number or not
	public static boolean isPerfect(int n){
		boolean perf = false;
      int sum = 0;
      int[] factors = new int[n]; //Array to store the factors
      if(n>0){
      //Nested 'for' loops to determine the factors
         for(int i=1;i<n;i++){
            for(int j=1;j<=n;j++){
               if(i*j==n) factors[i]=i;
            }
         }
         //Sums all the factors
         for(int i=1;i<n;i++){
            sum += factors[i];
         }
      }
      if(n==sum) perf=true;
      return perf; 
   }
} 
