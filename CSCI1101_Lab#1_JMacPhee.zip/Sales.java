/* CSCI 1101 - Lab #1 - Sales

   This program is the Sales class, it contains all attributes of 
   a sale, get and set methods for a sale, a method to print sale
   info to the screen, and a method to record a sale of an item.

   James MacPhee - B00768516 - Jan.16th/2018 */
   public class Sales{
   private String name;
   private double cost;
   private int bulkQuant;
   private double discount;
   private int numSold;
   private double total;
   private double totalDis;
   //No args constructor
   public Sales(){
   }
   //Constructor allowing intitial setting of attributes
   public Sales(String n, double c, int q, double d){
      name = n;
      cost = c;
      bulkQuant = q;
      discount = d;
   }
 /*
   ---A bunch of get and set methods--- 
 */
   public String getName(){
      return name;
   }
   public void setName(String n){
      name = n;
   }
   public double getCost(){
      return cost;
   }
   public void setCost(double c){
      cost = c;
   }
   public double getDiscount(){
      return discount;
   }
   public void setDiscount(double d){
      discount = d;
   }
   public int getBulkQuant(){
      return bulkQuant;
   }
   public void setBulkQuant(int q){
      bulkQuant = q;
   }
   //Method to record each sale and determine if a discount is to be applied
   public void registerSale(int n){
      numSold = n;
      if(n>bulkQuant){
         totalDis = cost*numSold*discount;
         cost = cost-(cost*discount);
         total = cost*numSold;
      }
      else{
         total = cost*numSold;
         totalDis = 0;
      }
   }
   //Method to print sale info of an item to the screen
   public void displaySales(){
      System.out.println(name);
      System.out.println("Number sold: "+numSold);
      System.out.println("Total Amount: "+total);
      System.out.println("Total Discount: "+totalDis);
      System.out.println("");
   }
}