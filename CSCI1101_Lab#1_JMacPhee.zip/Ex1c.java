/* CSCI 1101 - Lab #1 - Ex1c

   This program prints out every perfect number
   between 1 and 10,000.

   James MacPhee - B00768516 - Jan.16th/2018 */
import java.util.Scanner;
public class Ex1c{
	public static void main(String[] args){
		
      System.out.println("The perfect numbers between 1 and 10,000 are: ");
      int perfect;
      //A 'for' loop to run through every integer between 1 and 10,000
      for(int num=1;num<10000;num++){
         perfect = isPerfect(num);
         //If the isPerfect method returns a number other than zero than print it
         if(perfect != 0) System.out.print(perfect+" ");
	   }
   }
   //isPerfect method to determine if number is perfect or not
	public static int isPerfect(int n){
      
      int perfect=0;
      int sum = 0;
      int[] factors = new int[n]; //Array to store the factors
      
      //Nested 'for' loops to determine the factors
      for(int i=1;i<n;i++){
         if(n%i==0) factors[i]=i;
      }
      //Sums all the factors
      for(int i=1;i<n;i++){
         sum += factors[i];
      }
      if(n==sum) perfect=n;
      
      return perfect;
   }
} 
