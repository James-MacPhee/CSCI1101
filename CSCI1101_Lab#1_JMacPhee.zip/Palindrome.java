/* CSCI 1101 - Lab #1 - Palindrome

   This program determines whether or not a
   user inputted string is a palindrome or not. 

   James MacPhee - B00768516 - Jan.16th/2018 */
import java.util.Scanner;
public class Palindrome{
	public static void main(String[] args){
		
      Scanner kb = new Scanner(System.in);
      System.out.print("Please input a string: ");
      String str = kb.nextLine(); 
      String lowStr = str.toLowerCase(); //converts string to lowercase to make checking half as long
      String newStr = "";
      //A 'for' loop that sets newStr to lowStr but with only letters
      for(int i=0;i<lowStr.length();i++){
         if(lowStr.charAt(i)>='a'&&lowStr.charAt(i)<='z'){
            newStr += lowStr.charAt(i);
         }
      }
      if(isReverse(newStr) == true) System.out.print("\""+str+"\" is a palindrome.");
      else System.out.print("\""+str+"\" is NOT a palindrome.");
	}
   //isReverse method flips the string around and checks if the flipped string and original string are equal
	public static boolean isReverse (String line){
		
      String revLine = "";
      boolean check = false;
      //'for' loop to reverse string
      for(int i=line.length()-1;i>=0;i--){
         revLine += line.charAt(i);
      }
      if(revLine.equals(line)){
         check = true;
      }
      return check;
	}

	//add other methods if required
}
