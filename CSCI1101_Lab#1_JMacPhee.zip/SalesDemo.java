/* CSCI 1101 - Lab #1 - SalesDemo

   This program is simply creating two objects defined by the 'Sales'
   class. the two different constructors are used once each

   James MacPhee - B00768516 - Jan.16th/2018 */
   public class SalesDemo{
   public static void main(String[] args){
      //No args constructor being used
      Sales sale1 = new Sales();
      //Setting constructor being used
      Sales sale2 = new Sales("Toothpaste", 1.99, 20, .15);
      
      sale1.setName("Shampoo");
      sale1.setCost(2.50);
      sale1.setBulkQuant(4);
      sale1.setDiscount(.10);
      sale1.registerSale(10);
      sale1.displaySales();
      
      sale2.registerSale(10);
      sale2.displaySales();
   }
}