/* CSCI 1101 - Lab #1 - Ex1a

   This program takes a user inputted number and 
   prints out whether it is a perfect number or not.

   James MacPhee - B00768516 - Jan.16th/2018 */
import java.util.Scanner;
public class Ex1a{
	public static void main(String[] args){
		
      Scanner kb = new Scanner(System.in);
      System.out.print("Please input an integer: ");
      int num = kb.nextInt();
      int sum = 0;
      int[] factors = new int[num]; //Array to store the factors
      if(num>0){
      //Nested 'for' loops to determine the factors
         for(int i=1;i<num;i++){
            for(int j=1;j<=num;j++){
               if(i*j==num) factors[i]=i;
            }
         }
         //Sums all the factors
         for(int i=1;i<num;i++){
            sum += factors[i];
         }
         if(num==sum) System.out.print("The number "+num+" is a perfect number.");
         else System.out.print("The number "+num+" is NOT a perfect number.");
      }
      else System.out.print("The number "+num+" is NOT a perfect number.");
	}
} 
