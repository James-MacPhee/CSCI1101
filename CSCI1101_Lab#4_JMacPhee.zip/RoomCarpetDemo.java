/*CSCI 1101 - Lab #4 - RoomCarpetDemo

  This program uses the 'RoomDimension' and 'RoomCarpet' classes 
  and creates two rooms, carpets them both than uses the 
  'costsMore' method to determine which is the more costly job.

  James MacPhee - B00768516 - Feb.6th/2018 */
import java.util.Scanner;
public class  RoomCarpetDemo{
   public static void main(String[] args){
      //Methods to create and carpet rooms based on user specified dimensions and carpet price
      Scanner kb = new Scanner(System.in);
      System.out.print("Enter the dimensions for the first room: ");
      RoomDimension room1 = new RoomDimension(kb.nextDouble(),kb.nextDouble());
      System.out.print("Enter the cost per sq.ft of carpet: ");
      RoomCarpet carpet1 = new RoomCarpet(room1, kb.nextDouble());
      System.out.print("Enter the dimensions for the second room: ");
      RoomDimension room2 = new RoomDimension(kb.nextDouble(),kb.nextDouble());
      System.out.print("Enter the cost per sq.ft of carpet: ");
      RoomCarpet carpet2 = new RoomCarpet(room2, kb.nextDouble());
      //'If else' statements to determine correct print-out based on result of 'costsMore' method
      if(carpet1.costsMore(carpet2)){
         System.out.println("Room with "+carpet1);
         System.out.println("costs more than");
         System.out.println("Room with "+carpet2);
      }
      else{
         System.out.println("Room with "+carpet2);
         System.out.println("costs more than");
         System.out.println("Room with "+carpet1);
      }
   }
}