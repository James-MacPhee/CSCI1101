/*CSCI 1101 - Lab #4 - Point

  This program defines the attributes a 'point' object 
  should have and includes method that are useful to 
  find information about and manipulate points. 

  James MacPhee - B00768516 - Feb.6th/2018 */
public class Point{
   
   private int x;
   private int y;
   //Constructor that sets the x and y coordinates
   public Point(int x, int y){
      this.x = x;
      this.y = y;
   }
   public int getX(){
      return x;
   }
   public int getY(){
      return y;
   }
   //Methof to calculate and return the distance between two different points
   public double distanceFrom(Point p){
      return Math.sqrt(Math.pow((p.getX()-x),2)+Math.pow((p.getY()-y),2));
   }
   //toString method to improve readability
   public String toString(){
      return "("+x+","+y+")";
   }
}