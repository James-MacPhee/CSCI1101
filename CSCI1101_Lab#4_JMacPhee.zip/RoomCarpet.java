/*CSCI 1101 - Lab #4 - RoomCarpet

  This program aggregates from the RoomDimension class 
  and creates a carpet according to the dimensions of 
  the given room. The attributes are cost per square 
  foot of the room to be carpetted and the total cost.

  James MacPhee - B00768516 - Feb.6th/2018 */
public class RoomCarpet{

   private RoomDimension room;
   private double carpetCost;
   private double totalCost;
   //Constructor   
   public RoomCarpet(RoomDimension r, double cost){
      carpetCost = cost;
      room = r;
      totalCost = room.getLength()*room.getWidth()*carpetCost;
   }
   public double getTotalCost(){
      return totalCost;
   }
   //Method to determine which room of two will cost more to carpet
   public boolean costsMore(RoomCarpet other){
      if(this.totalCost>other.getTotalCost()) return true;
      else return false;
   }
   //toString method to improve readability
   public String toString(){
      return "Size: "+room+"  Carpet Cost(per sq.ft): $"+carpetCost+"  Total Cost: $"+totalCost;
   }
}