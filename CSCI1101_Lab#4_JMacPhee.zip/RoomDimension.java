/*CSCI 1101 - Lab #4 - RoomDimension

  This program specifies everything needed to create 
  an object 'RoomDimensions' consisting of simply 
  length and width of a room.

  James MacPhee - B00768516 - Feb.6th/2018 */
public class RoomDimension{
   
   private double length;
   private double width;
   //Constructor that takes in specified length and width
   public RoomDimension(double l, double w){
      length = l;
      width = w;
   }
   /* --- Get and Set Methods ---*/
   public double getLength(){
      return length;
   }
   public void setLength(double length){
      this.length = length;
   }
   public double getWidth(){
      return width;
   }
   public void setWidth(double width){
      this.width = width;
   }
   //toString method to improve readability
   public String toString(){
      return "Length: "+length+"ft  Width: "+width+"ft";
   }
}