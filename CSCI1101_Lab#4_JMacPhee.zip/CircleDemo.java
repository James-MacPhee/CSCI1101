/*CSCI 1101 - Lab #4 - CircleDemo

  This program utilizes the 'point' class and the 'circle' class to 
  demonstrate the capabilities of the methods inside the two classes.

  James MacPhee - B00768516 - Feb.6th/2018 */
public class CircleDemo{
   public static void main(String[] args){
      
      Point center1 = new Point(11,112);  //Creates point that will become center
      Circle circle1 = new Circle(center1,10); //creates circle using point as center
      Point tester1 = new Point(2,3);  //creates point to be passed into 'contains' method
      if(circle1.contains(tester1)) System.out.println("The point "+tester1+" is contained in the "+circle1);
      else System.out.println("The point "+tester1+" is NOT contained in the "+circle1);
      
      Point center2 = new Point(2,2);  //Creates point that will become center
      Circle circle2 = new Circle(center2,2);  //creates circle using point as center
      Point tester2 = new Point(2,2);  //creates point to be passed into 'touches' method
      if(circle2.touches(tester2)) System.out.println("The point "+tester2+" touches the perimeter of the "+circle2);
      else System.out.println("The point "+tester2+" doesn't touch the perimeter of the "+circle2);
   
      Point center3 = new Point(5,6);  //creates point to become center
      Circle circle3 = new Circle(center3,4);  //creates circle using point as center
      Point testCenter = new Point(3,4);  //creates point to become center of the testing circle
      Circle tester3 = new Circle();  //creates circle using above point as center
      if(circle3.contains(tester3)) System.out.println("The "+tester3+" is contained in the "+circle3);
      else System.out.println("The "+tester3+" is Not contained in the "+circle3);
   }
}