/*CSCI 1101 - Lab #4 - Circle

  This program defines a 'circle' object and the 
  attributes it should have, plus all the methods 
  that will be useful when finding out information 
  and manipulating that information about circles.
  This class is aggregated from the 'Point" class.

  James MacPhee - B00768516 - Feb.6th/2018 */
public class Circle{
   
   private Point center;
   private double radius;
   //No args constructor
   public Circle(){
      center = new Point(0,0);
      radius = 1;
   }
   //Constructor that takes in a specified center point and radius
   public Circle(Point center, double radius){
      this.center = center;
      this.radius = radius;
   }
   public Point getCenter(){
      return center;
   }
   public double getRadius(){
      return radius;
   }
   //Method to calculate and return the area
   public double getArea(){
      return Math.PI*radius*radius;
   }
   //Method to calculate and return the perimeter
   public double getPerimeter(){
      return 2*Math.PI*radius;
   }
   //Method to determine if a specified point is in a certain circle
   public boolean contains(Point p){
      if(center.distanceFrom(p)<radius) return true;
      else return false;
   }
   //Method to determine if a point is on the perimeter of a circle
   public boolean touches(Point p){
      if(center.distanceFrom(p)==radius) return true;
      else return false;
   }
   //Method to determine if a circle is inside a different circle
   public boolean contains(Circle c){
      if(this.contains(c.getCenter())){
         if(center.distanceFrom(c.getCenter())+c.getRadius()<this.radius) return true;
         else return false;
      }
      else return false;
   }
   //toString method to improve readability
   public String toString(){
      return "Circle with center: "+center+" and radius: "+radius;
   }
}