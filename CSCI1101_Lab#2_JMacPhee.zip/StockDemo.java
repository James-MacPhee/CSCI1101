/* CSCI 1101 - Lab #2 - StockDemo

   This program creates two objects to be used in the Stock.java class assigining
   user-inputted values to the appropriate attributes. It then prints out each 
   stocks information along with the comparison between the two and the total 
   value of one's portfolio.

   James MacPhee - B00768516 - Jan.23th/2018 */
import java.util.Scanner;
public class StockDemo{

	public static void main(String[] args){
		Scanner keyboard = new Scanner(System.in);
		String sym1, sym2;
		double prc1, prc2;
		int sh1, sh2;
		//Get the values for two stocks
		System.out.print("Enter the symbols for the two stocks: ");
		sym1 = keyboard.next();
		sym2 = keyboard.next();
		System.out.print("Enter their prices: ");
		prc1 = keyboard.nextDouble();
		prc2 = keyboard.nextDouble();
		System.out.print("Enter the number of shares for the two stocks: ");
		sh1 = keyboard.nextInt();
		sh2 = keyboard.nextInt();
		//create the first Stock
		Stock s1 = new Stock(sym1,prc1,sh1);
		//create the second Stock
		Stock s2 = new Stock(sym2,prc2,sh2);
      //print the symbol, price, and number of shares for each stock using toString method
      System.out.println("I have the following stocks:");
      System.out.println(s1);
      System.out.println(s2);
      //call in compare method and print out results
      if(s1.compare(s2)==1) System.out.println("The value of "+s1.getSymbol()+" is higher than "+s2.getSymbol()+" by $"+(s1.value()-s2.value()));
      else if(s1.compare(s2)==-1)  System.out.println("The value of "+s2.getSymbol()+" is higher than "+s1.getSymbol()+" by $"+(s2.value()-s1.value()));
      else System.out.println("The value of "+s1.getSymbol()+" and the value of "+s2.getSymbol()+" are the same.");
      //Determine and print total portfolio value
      System.out.println("The total value of my portfolio is $"+(s1.value()+s2.value()));
      System.out.print("\n\nProcess Completed.");
   }
}