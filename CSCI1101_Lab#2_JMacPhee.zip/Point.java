/* CSCI 1101 - Lab #2 - Point

   This program contains the neccessary instance variables and 
   methods in order to create a 'point' object, as well as methods 
   to determine if one point is higher than the other and another 
   to determine the length between to points. There is also a 
   toString method included to make readability of output easier.

   James MacPhee - B00768516 - Jan.23th/2018 */
import java.lang.Math;
public class Point{

   private double xPoint;
   private double yPoint;
   //Constructor method that sets coordinates
   public Point(double xPoint,double yPoint){
      this.xPoint = xPoint;
      this.yPoint = yPoint;
   }
   /*
  --Get and set methods for both the 'x' and 'y' coordinates--
  */
   public double getX(){
      return xPoint;
   }
   public void setX(double xPoint){
      this.xPoint = xPoint;
   }
   public double getY(){
      return yPoint;
   }
   public void setY(double yPoint){
      this.yPoint = yPoint;
   }
   //An unused method to determine if two compared points are equal
   public boolean equals(Point p){
      if(this.xPoint==p.getX() && this.yPoint==p.getY()) return true;
      else return false;
   }
   //isHigher method to determine which point of the two compared has a greater 'y' value
   public boolean isHigher(Point p){
      if(this.yPoint>p.getY()) return true;
      else return false;
   }
   //findLength method returns the length between two points
   public double findLength(Point p){
      return (Math.hypot((p.getX()-this.xPoint),(p.getY()-this.yPoint)));
   }
   //toString method to improve readability
   public String toString(){
      return "["+xPoint+","+yPoint+"]";
   }
}