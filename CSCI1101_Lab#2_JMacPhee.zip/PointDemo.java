/* CSCI 1101 - Lab #2 - PointDemo

   This program creates four 'point' objects, determines and prints the highest point,
   the length between the first and second point entered and the length between the 
   third and fourth point entered. The program than determines which length is longer.  
   
   ***I made all the coordinates doubles instead of ints to be able to use the 
   Math.hypot class. Plus I knew there was obviously a way to avoid the if/else 
   statements but wasn't sure if we were allowed to pass methods into arrays and such.
   I also could have made all that isHigher stuff into one method that took in the 
   remaining three points as parameters, and this would have cut down on space and code. 
   I didn't do this because it states in the lab handout to just compare 2 points in the 
   'isHigher" method not all four at once***
   
   James MacPhee - B00768516 - Jan.23th/2018 */
import java.util.Scanner;
public class PointDemo{
   public static void main(String[] args){
       
      Scanner kb = new Scanner(System.in);
      //Create four 'point' objects
      System.out.print("Enter the x and y coordinates for point1: ");
      Point p1 = new Point(kb.nextDouble(),kb.nextDouble());
      System.out.print("Enter the x and y coordinates for point2: ");
      Point p2 = new Point(kb.nextDouble(),kb.nextDouble());
      System.out.print("Enter the x and y coordinates for point3: ");
      Point p3 = new Point(kb.nextDouble(),kb.nextDouble());
      System.out.print("Enter the x and y coordinates for point4: ");
      Point p4 = new Point(kb.nextDouble(),kb.nextDouble());
      //If/else statements to determine the highest point according to 'y' coordinate
      if(p1.isHigher(p2)){
         if(p1.isHigher(p3)){
            if(p1.isHigher(p4)) System.out.println("\n"+p1+" is the highest point.");
            else System.out.println("\n"+p4+" is the highest point.");
         }
         else{
            if(p3.isHigher(p4)) System.out.println("\n"+p3+" is the highest point.");
            else System.out.println("\n"+p4+" is the highest point.");
         }
      }
      else{
         if(p2.isHigher(p3)){
            if(p2.isHigher(p4)) System.out.println("\n"+p2+" is the highest point.");
            else System.out.println("\n"+p4+" is the highest point.");
         }
         else{
            if(p3.isHigher(p4)) System.out.println("\n"+p3+" is the highest point.");
            else System.out.println("\n"+p4+" is the highest point.");
         }
      }
      //prints out length of each of the two lines
      System.out.println("\nThe length between "+p1+" and "+p2+" is "+p1.findLength(p2));
      System.out.println("The length between "+p3+" and "+p4+" is "+p3.findLength(p4));
      //prints out which line is longer
      if(p1.findLength(p2)>p3.findLength(p4)) System.out.print("Liner from "+p1+" to "+p2+" is longer");
      else System.out.print("Line from "+p3+" to "+p4+" is longer");
   }
}