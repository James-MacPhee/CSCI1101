/* CSCI 1101 - Lab #2 - Rectangle

   This program creates 'rectangle' objects 
   that have attributes of 'length' and 'width'.
   It also includes the appropriate methods to 
   conduct the actions requests in the RectangleDemo class.

   James MacPhee - B00768516 - Jan.23th/2018 */
public class Rectangle{
	
   private int length;
	private int width;
	//No args constructor
	public Rectangle(){
	}
   //Constructor that sets the attributes of the object 
   public Rectangle(int l, int w){
      this.length = l;
      this.width = w;
   }
   /*
  --Get and set methods for length and width--
  */
	public void setLength(int l){
		this.length = l;
	}
	public void setWidth(int w){
		this.width = w;
	}
	public int getLength(){
		return length;
	}
	public int getWidth(){
		return width;
	}
   //findArea method to determine 'area' attribute of the object
	public int findArea(){
		return length*width;
	}
   //toString method to help users read the output
   public String toString(){
      return "Length: "+length+"    Width: "+width;
   }
}