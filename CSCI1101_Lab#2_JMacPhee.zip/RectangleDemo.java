/* CSCI 1101 - Lab #2 - RectangleDemo

   This program uses the rectangle class and creates 
   an object of type 'Rectangle', prints its two 
   attributes, and then calls the findArea method 
   to determine its area.

   James MacPhee - B00768516 - Jan.23th/2018 */
import java.util.Scanner;
public class RectangleDemo{
	public static void main(String[] args){
		
      Scanner kb = new Scanner(System.in);
      Rectangle rect1 = new Rectangle();
      System.out.print("Enter length and width: ");
		rect1.setLength(kb.nextInt());
		rect1.setWidth(kb.nextInt());
      System.out.println(rect1);		
		System.out.println("Area: " + rect1.findArea());
	}
}