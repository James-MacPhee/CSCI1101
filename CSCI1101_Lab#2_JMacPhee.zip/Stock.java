/* CSCI 1101 - Lab #2 - Stock

   This program contains all the attributes that a certain 
   stock would contain plus includes methods for finding a 
   stocks value inside of your portfolio as well as to compare
   two methods againest each other.

   James MacPhee - B00768516 - Jan.23th/2018 */
public class Stock{
   
   private String symbol;
   private double price;
   private int numShares;
   //Constructor with ability to set symbol, price, and number of shares
   public Stock(String symbol, double price, int numShares){
      this.symbol = symbol; 
      this.price = price;
      this.numShares = numShares;  
   }
   
  /*
  --Get and set methods for symbol, price, and numShares--
  */
   public String getSymbol(){
      return symbol;
   }
   public void setSymbol(){
      this.symbol = symbol;
   }
   public double getPrice(){
      return price;
   }
   public void setPrice(){
      this.price = price;
   }
   public int getNumShares(){
      return numShares;
   }
   public void setNumShares(){
      this.numShares = numShares;
   }
   //toString method for readable printing to display
   public String toString(){
      return "Symbol: "+symbol+"\nPrice: "+price+"\nNumber of Shares: "+numShares;
   }
   //value method to determine and return value of the stock in question
   public double value(){
      return price*numShares;
   }
   //Compares two stock's value together
   public int compare(Stock s){
      if(this.value()>s.value()) return 1;
      else if(this.value()<s.value()) return -1;
      else return 0;
   }
}