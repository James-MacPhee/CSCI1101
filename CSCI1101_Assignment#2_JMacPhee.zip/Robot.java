/*CSCI 1101 - Assignment #2 - Robot

  This program defines a robot object with a given name and can be 
  placed in a certain row and column of a 'Track' for a 'Race'.

  James MacPhee - B00768516 - March.2nd/2018 */
public class Robot{

   private String name;
   private int row;
   private int col;
   //Constructor that
   public Robot(String name, int row, int col){
      this.name = name;
      this.row = row;
      this.col = col;
   }
   // --- Get and Set methods ---
   public void setName(String name){
      this.name = name;
   }
   public String getName(){
      return name;
   }
    public void setRow(int row){
      this.row = row;
   }
   public int getRow(){
      return row;
   }
   public void setCol(int Col){
      this.col = col;
   }
   public int getCol(){
      return col;
   }
   //'move' method to simply update a robot's row and col to reflect its spot in the array
   public void move(int row,int col){
      this.row = row;
      this.col = col;
      
   }
}