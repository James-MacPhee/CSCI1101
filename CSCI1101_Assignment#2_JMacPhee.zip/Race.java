/*CSCI 1101 - Assignment #2 - Race

  This program .............................

  James MacPhee - B00768516 - March.2nd/2018 */
public class Race{

   private Track track1;
   private Robot robot1;
   private Robot robot2;
   private static boolean winner;
   private static int turn = 0;
   //Constructor that creates a Race with the given 'Track', and 'Robot's
   public Race(Track track1, Robot robot1, Robot robot2){
      this.track1 = track1;
      this.robot1 = robot1;
      this.robot2 = robot2;
      winner = false;
   }
   public void move(int direction, int steps){
      System.out.println();
      if(turn==0){
         System.out.print(robot1.getName()+" turn.\tDir: ");
         if(direction==0){
            System.out.println("Forwards\tSteps: "+steps);
            if(steps+robot1.getCol()<=track1.getCol()-1) robot1.move(0,robot1.getCol()+steps);
            else System.out.println("Movement parameters invalid. Turn skipped.");
         }
         else{
            System.out.println("Backwards\tSteps: "+steps);
            if(robot1.getCol()-steps>=0) robot1.move(0,robot1.getCol()-steps);
            else System.out.println("Movement parameters invalid. Turn skipped.");
         }
         turn = 1;
         track1.printTrack(robot1,robot2);
         winner();
      }
      else{
         System.out.print(robot2.getName()+" turn.\tDir: ");
         if(direction==0){
            System.out.println("Forwards\tSteps: "+steps);
            if(steps+robot2.getCol()<=track1.getCol()-1) robot2.move(1,robot2.getCol()+steps);
            else System.out.println("Movement parameters invalid. Turn skipped.");
         }
         else{
            System.out.println("Backwards\tSteps: "+steps);
            if(robot2.getCol()-steps>=0) robot2.move(1,robot2.getCol()-steps);
            else System.out.println("Movement parameters invalid. Turn skipped.");
         }
         turn = 0;
         track1.printTrack(robot1,robot2);
         winner();
      } 
   }
   public static boolean getWinner(){
      return winner;
   }
   public void winner(){
      if(robot1.getCol()==track1.getCol()-1){
         winner = true;
      }
      else if(robot2.getCol()==track1.getCol()-1){
         winner = true;
      }
   }
}