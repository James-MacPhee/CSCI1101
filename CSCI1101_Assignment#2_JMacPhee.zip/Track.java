/*CSCI 1101 - Assignment #2 - Track

  This program defines a Track object that has a 2D array 
  that is used to hold the printouts for the Track.
  The Track will be used in a 'Race'.

  James MacPhee - B00768516 - March.2nd/2018 */
public class Track{

   private String[][] track;
   private int row;
   private int col;
   //Constructor that creates a 2D array with given lengths and sets 'row' and 'col' attributes
   public Track(int row, int col){
      this.row = row;
      this.col = col;
      track = new String[row][col];
   }
   // --- Get and Set methods ---
   public void setRow(int row){
      this.row = row;
   }
   public int getRow(){
      return row;
   }
   public void setCol(int Col){
      this.col = col;
   }
   public int getCol(){
      return col;
   }
   public String[][] getTrack(){
      return track;
   }
   public void setTrack(String[][] track){
      this.track = track;  
   }
   //method that prints out a blank track depending on the user-specified length.
   public void printTrack(){
      System.out.println();
      for(int i=0;i<track.length;i++){
         for(int j=0;j<track[i].length;j++){
            System.out.print("_");
         }
         System.out.println();
      }
   }
   //Prints each element of the track in a readable way, after populating the track with the robots.
   public void printTrack(Robot robot1, Robot robot2){
      System.out.println();
      //populating part of method
      for(int i=0;i<2;i++){
         for(int j=0;j<track[i].length;j++){
            if(robot1.getCol()==j&&robot1.getRow()==i) track[i][j] = robot1.getName();
            else if(robot2.getCol()==j&&robot2.getRow()==i) track[i][j] = robot2.getName();
            else track[i][j] = "_";
         }
      }
      //printing part of method
      for(int i=0;i<track.length;i++){
         for(int j=0;j<track[i].length;j++){
            System.out.print(track[i][j]);
         }
         System.out.println();
      }
   }
}