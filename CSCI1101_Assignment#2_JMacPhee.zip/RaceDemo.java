/*CSCI 1101 - Assignment #2 - RaceDemo

  This program creates creates a 'Race' object ands performs a race of two 'Robot's on a 'track'.

  James MacPhee - B00768516 - March.2nd/2018 */
import java.util.Scanner;
import java.util.Random;
public class RaceDemo{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      Random rn = new Random();
      System.out.println("Welcome to the ROBOT RACE!\n");
      System.out.print("Enter Robot #1 name: ");
      Robot robot1 = new Robot(kb.next(),0,0);
      System.out.print("Enter Robot #2 name: ");
      Robot robot2 = new Robot(kb.next(),1,0);
      System.out.print("\nEnter the length of the race track: ");
      Track track = new Track(2,kb.nextInt()+1);
      Race race1 = new Race(track,robot1,robot2);
      System.out.println("\n\nGet Ready, Get Set, GO!\nSTART RACE!\n");
      track.printTrack(robot1, robot2);
      while(race1.getWinner()==false){
         race1.move(rn.nextInt(2),rn.nextInt(3));
      }
      if(robot1.getCol()==track.getCol()-1) System.out.print(robot1.getName()+" is the winner!!!!");
      else System.out.print(robot2.getName()+" is the winner!!!!");
   }
}