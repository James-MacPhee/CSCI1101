/*CSCI 1101 - Lab #7 - LinkedList
  
  This program simply defines the common 'LinkedList' object and includes some extra manipulative methods

  James MacPhee - B00768516 - March.16th/2018 */ 
public class LinkedList{ 
  private Node front; 
  private int count; 
//constructor 
  public LinkedList(){ 
      front = null; count = 0; 
  } 
//add a node to the front of the linked list 
  public void addToFront(String d){ 
      Node n = new Node(d, front);
      front = n;
      count++; 
  } 

  //get the current size of the list 
  public int size(){
     return count; 
  } 
  //check if the list is empty 
  public boolean isEmpty(){
     return (count==0);
  } 
  //clear the list 
  public void clear(){ 
     front = null; count=0; 
  } 
  //get the content of the first node 
  public String getFrontData() { 
      if (front==null)
         return "Empty list"; 
      else
         return front.getData(); 
  }  
  //new method added - get the first node 
  public Node getFront() { 
      return front; 
  } 
  //scan the list and print contents 
  public void enumerate() { 
      Node curr = front; 
      while (curr!=null) { 
         System.out.print(curr); 
         curr = curr.getNext(); 
      } 
      System.out.println("."); 
  }
  //Prints the contents of Nodes with even indices
  public void printEvenIndex(){
     int counter = 0;
     Node curr = front; 
     while (curr!=null) { 
        if(counter%2==0){
           System.out.print(curr); 
        }
        curr = curr.getNext();
        counter++;
     } 
     System.out.println(".");    
  }
  //Lists the index of Node that contain the inputted String
  public void listAllNodesWith(String d){
     int counter = 0;
     Node curr = front; 
     while (curr!=null){
        if(curr.getData().equals(d)){ 
        System.out.print(counter+" ");
        }
        counter++; 
        curr = curr.getNext(); 
     }
     System.out.println();
  }
  //Adds the inputted String into the second Node
  public void addAsSecondNode(String d){
     Node curr = front.getNext();
     Node n = new Node(d, curr);
     n.setNext(curr);
     front.setNext(n);
     count++;
  } 
} 
