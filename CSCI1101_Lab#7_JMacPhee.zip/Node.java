/*CSCI 1101 - Lab #7 - Node
  
  This program simply defines the common 'Node' object

  James MacPhee - B00768516 - March.16th/2018 */
public class Node{ 
   
   private String data;
   private Node next;
   //Constructor
   public Node(String d, Node n){ 
      data = d; 
      next = n; 
   }
   // --- Get and Set Methods --- 
   public String getData(){
      return data;
   } 
   public Node getNext(){
      return next;
   }
   public void setData(String d){
      data = d;
   }
   public void setNext(Node n){
      next = n;
   }
   //toString method to improve readability
   public String toString(){ 
      return data + "-->"; 
  } 
} 
