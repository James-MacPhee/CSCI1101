/*CSCI 1101 - Lab #7 - LinkedListDemo
  
  This program utilizes both the LinkedList and Node classes including the added methods to experiment with LinkedLists

  James MacPhee - B00768516 - March.16th/2018 */
public class LinkedListDemo {
  public static void main(String[] args) { 
      
      LinkedList myList = new LinkedList(); 
      myList.addToFront("Running"); 
      myList.addToFront("Swimming"); 
      myList.addToFront("Walking"); 
      myList.addToFront("Running");
      myList.addToFront("Running");
      System.out.println("Number of nodes in the list: "+ myList.size()); 
      myList.enumerate();
      myList.addToFront("Skiing");
      myList.addToFront("Jumping");
      myList.enumerate();
      myList.printEvenIndex();
      myList.listAllNodesWith("Running");
      myList.addAsSecondNode("Skating"); 
      myList.enumerate();
  } 
} 
