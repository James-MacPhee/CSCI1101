/*CSCI 1101 - Lab #3 - TestRectangle2D

  This program creates a 'Rectangle2D' object defined in 
  the Rectangle2D class and makes use of the various methods.

  James MacPhee - B00768516 - Jan.30th/2018 */
public class TestRectangle2D{
   public static void main(String[] args){
   
      Rectangle2D r1 = new Rectangle2D(1,1,5,49);
      System.out.println("Area: "+r1.getArea()+"\nPerimeter: "+r1.getPerimeter());
      //'If else' to determine the result of contains.(point) method
      if(r1.contains(3,-3)) System.out.println("The point is contained in the rectangle.");
      else System.out.println("The point is NOT contained in the rectangle.");
      //'If else' to determine the result of contains.(rectangle) method
      if(r1.contains(new Rectangle2D(2,2,1,32))) System.out.println("The new rectangle is contained in the original rectangle.");
      else System.out.println("The new rectangle is NOT contained in the original rectangle");
   }
}