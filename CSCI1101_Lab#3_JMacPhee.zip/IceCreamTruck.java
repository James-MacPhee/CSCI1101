/*CSCI 1101 - Lab #3 - IceCreamTruck

  This program defines an IceCreamTruck and its 
  attributes truckID and number of ice cream sold, 
  as well as three variables; final number of ice-creams 
  sold, price of an ice-cream, and the number of trucks.

  James MacPhee - B00768516 - Jan.30th/2018 */
public class IceCreamTruck{
   
   private String truckID;
   private int numSold = 0;
   static int numFinal = 0;
   static double price;
   static int numTrucks = 0;
   //Constructor creating a new IceCreamTruck with the specified truckID
   public IceCreamTruck(String truckID){
      this.truckID = truckID;
      numSold = 0;
      numTrucks += 1;
   }
   //Registers and records a sale of an ice-cream
   public void sale(){
      numSold += 1;
      numFinal += 1;
   }
   //toString method to improve readability
   public String toString(){
      return "Ice-creams sold by "+truckID+": "+numSold+"  Total sales for "+truckID+": "+numSold*price;
   }
   //Method to set the price of an ice-cream
   public static void setPrice(double p){
      price = p;
   }
   //Methoid to return the final number of ice-creams sold
   public static int getNumFinal(){
      return numFinal;
   }
   //Method to return the price of an ice-cream
   public static double getPrice(){
      return price;
   }
   //Method that calculates and returns the average money generated per IceCreamTruck
   public static double aveSales(){
      return numFinal*price/numTrucks;
   }
}