/*CSCI 1101 - Lab #3 - Rectangle2D

  This program defines a rectangle object and 
  its attributes; width, height, x coordinate, 
  and y coordinate. It also contains useful 
  methods to retrieve information on the rectangles 
  created.

  James MacPhee - B00768516 - Jan.30th/2018 */
public class Rectangle2D{

   private double width;
   private double height;
   private double xpos;
   private double ypos;
   //No args constructor
   public Rectangle2D(){
      width = 0;
      height = 0;
      xpos = 0;
      ypos = 0;
   }
   //Constructor that sets x,y coordinates as well as width and height
   public Rectangle2D(double xpos, double ypos, double width, double height){
      this.width = width;
      this.height = height;
      this.xpos = xpos;
      this.ypos = ypos;
   }
   /*--- Get and Set Methods ---*/
   public void setWidth(double width){
      this.width = width;
   }
   public double getWidth(){
      return width;
   }
   public void setHeight(){
      this.height = height;
   }
   public double getHeight(){
      return height;
   }
   public void setXpos(){
      this.xpos = xpos;
   }
   public double getXpos(){
      return xpos;
   }
   public void setYpos(){
      this.ypos = ypos;
   }
   public double getYpos(){
      return ypos;
   }
   //Method to calculate and return area of rectangle
   public double getArea(){
      return width*height;
   }
   //Method to calculate and return perimeter of rectangle
   public double getPerimeter(){
      return 2*(width+height);
   }
   //Method to determine if a specified point is inside created Rectangle2D object
   public boolean contains(double x, double y){
      if(xpos+width>x&&xpos<x&&ypos+height>y&&ypos<y) return true;
      else return false;
   }
   //Method to determine if a new pecified rectangle is inside created Rectangle2D object
   public boolean contains(Rectangle2D r){
      if(this.xpos<=r.getXpos()&&this.ypos<=r.getYpos()&&this.xpos+this.width>=r.getXpos()+r.getWidth()&&this.ypos+this.height>=r.getYpos()+r.getHeight()) 
         return true;
      else return false;
   }
}