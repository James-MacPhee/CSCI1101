/*CSCI 1101 - Lab #3 - IceCreamTest

  This program creates multiple 'IceCreamTruck's and 
  generates sale(s) for them then prints out each ones 
  details defined in the toString method.
  After that it utilizes the 'aveSales' and 'numFinal' 
  methods to print out that information.

  James MacPhee - B00768516 - Jan.30th/2018 */
public class IceCreamTest{
   public static void main(String[] args){
      //Creating 5 ice cream trucks
      IceCreamTruck truck1 = new IceCreamTruck("Truck1");
      IceCreamTruck truck2 = new IceCreamTruck("Truck2");
      IceCreamTruck truck3 = new IceCreamTruck("Truck3");
      IceCreamTruck truck4 = new IceCreamTruck("Truck4");
      IceCreamTruck truck5 = new IceCreamTruck("Truck5");
      IceCreamTruck.setPrice(10);
      //Generating sales for trucks
      truck1.sale();
      truck2.sale();
      truck3.sale();
      truck4.sale();
      truck5.sale();
      System.out.println("Ice-cream sales by truck:");
      System.out.println(truck1);
      System.out.println(truck2);
      System.out.println(truck3);
      System.out.println(truck4);
      System.out.println(truck5);
      System.out.println("\nTotal Ice-cream sold by all trucks: "+IceCreamTruck.getNumFinal()); 
      System.out.println("Total Sales: $"+IceCreamTruck.getNumFinal()*IceCreamTruck.getPrice());
      System.out.println("Average sales per truck: $"+IceCreamTruck.aveSales());
      System.out.print("\nProcess Completed.");
   }
}