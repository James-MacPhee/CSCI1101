/*CSCI 1101 - Assignment #2 - MotorBoats

  This program defines attributes and method needed to create a 'MotorBoat' object.

  James MacPhee - B00768516 - Jan.25th/2018 */
public class MotorBoats{

   private String name;
   private double capacity;
   private double fuel;
   private double max;
   private double speed;
   private double consumption;
   private double distance;
   //Constructor for MotorBoat object
   public MotorBoats(String name, double capacity, double fuel, double max, double consumption){
      this.name = name;
      this.capacity = capacity;
      this.fuel = fuel;
      this.max = max;
      this.consumption = consumption;
      distance = 0;
      speed = 0;
   }
   /* ---Get and set methods---*/
   public String getName(){
      return name;
   }
   public void setName(String name){
      this.name = name;
   }
   public double getCapacity(){
      return capacity;
   }
   public void setCapcity(double capacity){
      this.capacity = capacity;
   }
   public double getFuel(){
      return fuel;
   }
   public void setFuel(double fuel){
      this.fuel = fuel;
   }
   public double getMax(){
      return max;
   }
   public void setMax(double max){
      this.max = max;
   }
   public double getSpeed(){
      return speed;
   }
   public void setSpeed(double speed){
      this.speed = speed;
   }
   public double getConsumption(){
      return consumption;
   }
   public void setConsumption(double consumption){
      this.consumption = consumption;
   }
   public double getDistance(){
      return distance;
   }
   public void setDistance(double distance){
      this.distance = distance;
   }
   //Method to change current speed of a motorboat
   public void changeSpeed(double speedChange){
      if(speed+speedChange>max||0-speed+speedChange>max) speed = max;
      else speed = speed+speedChange; 
   }
   //Method to set theboat to cruise and run it at a certain speed for a certain amount of time
   public void cruise(double time){
      time = time/60;
      distance = speed*time;
      fuel = fuel-consumption*distance;
   }
   //Method to fill the boat with a certain amount of fuel
   public void increaseFuel(double fill){
      if(fuel+fill<capacity) fuel = fuel+fill;
      else fuel = capacity;
   }
   //Method that determinees the faster of two MotorBoats being compared
   public boolean fasterBoat(MotorBoats boat){
      if(this.max>boat.getMax()) return true;
      else return false;
   }
   //Method to determine if two boats are equal
   public boolean equals(MotorBoats boat){
      if(this.max==boat.getMax()&&this.capacity==boat.getCapacity()&&this.consumption==boat.getConsumption()) return true;
      else return false;
   }
   //toString method to improve readability
   public String toString(){
      return "Motorboat: "+name+"\nSpeed: "+speed+" kmph\nDistance travelled: "+distance+" km\nFuel left: "+fuel+" Litres\n";
   }
}