/*CSCI 1101 - Assignment #1 - TestDoor

  This program utilizes loops, random number generators, and the Door class 
  to make a simple game. All the user has to do is enter Y or N and every time 
  they enter Y the program will generate a door desrcibed in the Door class 
  and will tell the player if they have found the treasure or not.

  James MacPhee - B00768516 - Jan.25th/2018 */
import java.util.Scanner;
import java.util.Random;
public class TestDoor{
   public static void main(String[] args){
   
      boolean key;
      //'entered' variable to keep track whether player has entered or not
      boolean entered = false;
      String play;
      String title;
      
      Scanner kb = new Scanner(System.in);
      Random rn = new Random();
      System.out.println("Welcome to the dungeon.");
      System.out.print("Play? (Enter Y or N): ");
      play = kb.next();
      //'While' loop to keep making new door objects each time a player decides to play
      while(play.equals("Y")||play.equals("y")){
         
         Door door1 = new Door(true,true);
         //'a' variable used to determine a random key value
         int a = rn.nextInt(2);
         if(a==1) key = true;
         else key = false;
         //'if' statements to determine what the door status and print out to user should be for the seperate cases
         if(key==true&&door1.getInscription().equals("Enter")){
            if(entered==true){
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("You can't enter if you already have entered.");
            }
            else{
               door1.unlock();
               door1.open();
               entered = true;
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("Entered");
            }
         }
         else if(key==true&&door1.getInscription().equals("Exit")){
            if(entered==true){
               door1.unlock();
               door1.open();
               entered = false;
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("Exited");
            }
            else{
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("Can't exit without entering first.");
            }
         }
         else if(key==true&&door1.getInscription().equals("Treasure")){
            if(entered==true){
               door1.unlock();
               door1.open();
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("TREASURE FOUND");
            }
            else{
               System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
               System.out.println("Can't get to treasure without entering first.");
            }
         }
         else if(key==false&&door1.getInscription().equals("Enter")){
            System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
            System.out.println("Sorry. You do not have the key.");
         }
         else if(key==false&&door1.getInscription().equals("Exit")){
            System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
            System.out.println("Sorry. You do not have the key.");
         }
         else{
            System.out.println("Door: "+door1.getInscription()+"\nKey: "+key);
            System.out.println("Sorry. You do not have the key.");
         }
         System.out.print("\nPlay? (Enter Y or N): ");
         play = kb.next();
      }
   }
}