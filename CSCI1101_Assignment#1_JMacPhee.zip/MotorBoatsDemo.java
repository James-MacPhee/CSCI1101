/*CSCI 1101 - Lab #3 - MotorBoatsDemo

  This program .................

  James MacPhee - B00768516 - Jan.25th/2018 */
public class MotorBoatsDemo{
   public static void main(String[] args){
      
      //Creates first MotorBoat
      MotorBoats boat1 = new MotorBoats("Speedy",100,50,100,1);
      boat1.setSpeed(25); //sets speed of boat1
      boat1.cruise(30); //runs boat1
      System.out.println(boat1);
      boat1.changeSpeed(25);//changes boat1's speed
      boat1.cruise(30);//runs boat1
      System.out.println(boat1);
      //creates a second boat
      MotorBoats boat2 = new MotorBoats("Flippy",90,45,120,.75);
      boat2.setSpeed(45); //sets speed of boat2
      boat2.cruise(20); //runs boat2
      System.out.println(boat2);
      boat2.increaseFuel(50); //fills boat2 with fuel
      boat2.changeSpeed(15);
      boat2.cruise(30);
      System.out.println(boat2);
      System.out.print("Fastest Boat: ");
      //'if else' statements to determine faster boat between boat1 and boat2
      if(boat1.fasterBoat(boat2)) System.out.println(boat1.getName());
      else System.out.println(boat2.getName());
      if(boat1.equals(boat2)) System.out.println("\n"+boat1.getName()+" and "+boat2.getName()+" are the same boat.");
      else System.out.println("\n"+boat1.getName()+" and "+boat2.getName()+" are not the same boat.");
   }
}