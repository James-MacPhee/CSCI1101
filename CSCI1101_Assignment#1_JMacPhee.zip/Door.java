/*CSCI 1101 - Assignment #1 - Door

  This program creates holds the attributes and methods to make and use a 'door' object.

  James MacPhee - B00768516 - Jan.25th/2018 */
import java.util.Random;
public class Door{
   Random rn = new Random();
   //Atrributes a door would have
   private String inscription;
   private boolean locked;
   private boolean closed;
   //Constructor for a door object
   public Door(boolean locked, boolean closed){
      this.locked = locked;
      this.closed = closed;
      int code = rn.nextInt(3);
      if(code==2) inscription = "Enter";
      else if(code==1) inscription = "Exit";
      else inscription = "Treasure";
   }
   //Method to check if the door is closed or open
   public boolean isClosed(){
      return closed;
   }
   //Method to check if the door is locked or not
   public boolean isLocked(){
      return locked;
   }
   //Opens a door if it is closed and unlocked
   public void open(){
      if(closed&&!locked) closed = false;
      else System.out.println("Door is not able to be opened");
   }
   //closes a door if it is open
   public void close(){
      if(!closed) closed = true;
      else System.out.println("Door is not able to be closed");
   }
   //locks a door if it is closed and unlocked
   public void lock(){
      if(closed&&!locked) locked = true;
      else System.out.println("Door is not able to be locked");
   }
   //unlocks a door if it closed and locked
   public void unlock(){
      if(closed&&locked) locked = false;
      else System.out.println("Door is not able to be unlocked");
   }
   //Method to retrieve the inscription for a door
   public String getInscription(){
      return inscription;
   }
   //toString method to improve readability
   public String toString(){
      return "Inscription: "+inscription+"\n locked: "+locked+"\n Closed: "+closed;
   }   
}