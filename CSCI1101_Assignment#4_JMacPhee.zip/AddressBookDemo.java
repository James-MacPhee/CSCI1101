/*CSCI 1101 - Assignment #4 - AddressBookDemo
  
  This program creates an instance of the 'AddressBook' 
  object and fills its LinkList with Contact objects and
  uses the methods described in the AddressBook class.

  James MacPhee - B00768516 - April.4th/2018 */
import java.util.Scanner;
public class AddressBookDemo{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      AddressBook book = new AddressBook();
      int input = 0;
      while(input!=5){
         System.out.print("\nEnter 1 to add contact, 2 to display, 3 to search, 4 to delete, 5 to quit: ");
         input = kb.nextInt();
         if(input==1){
            System.out.print("Enter last name: ");
            String last = kb.next();
            System.out.print("Enter first name: ");
            String first = kb.next();
            System.out.print("Enter street name: ");
            String street = kb.next();
            System.out.print("Enter phone number: ");
            String phone = kb.next();
            Contact c = new Contact(last,first,street,phone);
            book.addContact(c);  
         }
         else if(input==2){
            book.displayAllContacts();
         }
         else if(input==3){
            System.out.print("\nEnter 1 to search name, 2 to search address, 3 to search phone number: ");
            int n = kb.nextInt();
            System.out.print("Enter what to search: ");
            String s = kb.next();
            book.search(s,n);
         }
         else if(input==4){
            System.out.print("\nEnter 1 to search name, 2 to search address, 3 to search phone number: ");
            int n = kb.nextInt();
            System.out.print("Enter what to search: ");
            String s = kb.next();
            book.remove(s,n);  
         }
         else if(input==5) System.out.print("Good-bye!");     
         else System.out.print("Invalid input, please try again");
      }
   }
}