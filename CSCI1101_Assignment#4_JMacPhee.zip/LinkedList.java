/*CSCI 1101 - Assignment #4 - LinkedList
  
  This program simply defines the common 'LinkedList' object and includes some extra manipulative methods

  James MacPhee - B00768516 - April3.4th/2018 */
import java.util.Scanner; 
public class LinkedList{ 
  private Node front; 
  private Node last;
  private int count;
  
  Scanner kb = new Scanner(System.in); 
  //constructor 
  public LinkedList(){ 
      front = null;
      last = null; 
      count = 0; 
  } 
  //add a node to the front of the linked list 
  public void add(Contact c){ 
     if(count==0){
        front = new Node (c,null);         
        count++;
        last = front;
     }
     else{
        Node temp = front;
        if(count==1){
           if(c.getLastName().compareToIgnoreCase(front.getData().getLastName())<0){
              Node curr = new Node(c,front);
              count++;
              last = front;
              front = curr;
           }
           else if(c.getLastName().compareToIgnoreCase(front.getData().getLastName())==0){
              if(c.getFirstName().compareToIgnoreCase(front.getData().getFirstName())<0){
                 Node curr = new Node(c,front);
                 count++;
                 last = front;
                 front = curr;
              }
           }
           else{
              Node curr = new Node(c,null);
              front.setNext(curr);
              count++;
              last = curr;
           }
        }
        else{
           while(temp!=null){
              if(c.getLastName().compareToIgnoreCase(last.getData().getLastName())>0){
                 Node curr = new Node(c,null);
                 count++;
                 last.setNext(curr);
                 last = curr;
                 break;
              }
              else if(c.getLastName().compareToIgnoreCase(front.getData().getLastName())<0){
                 Node curr = new Node(c,front);
                 front = curr;
                 count++;
                 break;
              }
              else if(c.getLastName().compareToIgnoreCase(temp.getNext().getData().getLastName())<0){
                 Node curr = new Node(c,temp.getNext());
                 temp.setNext(curr);
                 count++;
                 break;
              }
              else if(c.getLastName().compareToIgnoreCase(temp.getNext().getData().getLastName())==0){
                 if(c.getFirstName().compareToIgnoreCase(temp.getNext().getData().getFirstName())<0){
                    Node curr = new Node(c,temp.getNext());
                    temp.setNext(curr);
                    count++;
                    break;
                    
                 }
                 else if(c.getFirstName().compareToIgnoreCase(temp.getNext().getData().getFirstName())==0){
                    break;
                 }
                 else{
                    temp = temp.getNext();
                 }
              }
              else if(c.getLastName().compareToIgnoreCase(last.getData().getLastName())==0){
                 if(c.getFirstName().compareToIgnoreCase(last.getData().getFirstName())>0){
                    Node curr = new Node(c,null);
                    count++;
                    last.setNext(curr);
                    last = curr;
                    break;
                 }
                 else if(c.getFirstName().compareToIgnoreCase(last.getData().getFirstName())==0){
                  break;
                 }
                 else{
                    temp = temp.getNext();
                 }
              }
              else{
                 temp = temp.getNext();
              } 
           }
        }
     }
  }
  //get the current size of the list 
  public int size(){
     return count; 
  } 
  //check if the list is empty 
  public boolean isEmpty(){
     return (count==0);
  } 
  //clear the list 
  public void clear(){ 
     front = null; count=0; 
  } 
  //get the content of the first node 
  public Contact getFrontData() { 
         return front.getData(); 
  }  
  //new method added - get the first node 
  public Node getFront() { 
      return front; 
  } 
  //Prints the contents of Nodes with even indices
  public void display(){
     if(count!=0){
        Node curr = front; 
        while (curr!=null) { 
           System.out.println(curr); 
           curr = curr.getNext();
        }     
     }
     else System.out.println("No contacts to display.");
  }
  //Lists the index of Node that contain the inputted Contact
  public void search(String s, int n){
     Node curr = front;
     if(n==1){ 
        while (curr!=null){
           if(curr.getData().getLastName().equalsIgnoreCase(s)||curr.getData().getFirstName().equalsIgnoreCase(s)){ 
              System.out.println(curr);
           } 
           curr = curr.getNext(); 
        }
        System.out.println();
     }
     else if(n==2){
        while (curr!=null){
           if(curr.getData().getStreetName().equalsIgnoreCase(s)){ 
              System.out.println(curr);
           } 
           curr = curr.getNext(); 
        }
        System.out.println();
     }
     else if(n==3){
        while (curr!=null){
           if(curr.getData().getPhone().contains(s)){ 
              System.out.println(curr);
           } 
           curr = curr.getNext(); 
        }
        System.out.println();
     }
  }
  //Determines a certain contact that the user wants removed from the addressbook
  public void remove(String s, int n){
    Node curr = front;
    int counter = 1;
    
    if(n==1){ 
         while (curr!=null){
             if(curr.getData().getLastName().equalsIgnoreCase(s)||curr.getData().getFirstName().equalsIgnoreCase(s)){ 
                System.out.println(counter+". "+curr);
                counter++;
             } 
             curr = curr.getNext();
         }
         System.out.print("\nEntry to delete: ");
         int a = kb.nextInt();
         int i = 1;
         curr = front;
         if((front.getData().getLastName().equalsIgnoreCase(s)||front.getData().getFirstName().equalsIgnoreCase(s))&&a==i){
            front = front.getNext();
         }
         else if((last.getData().getLastName().equalsIgnoreCase(s)||last.getData().getFirstName().equalsIgnoreCase(s))&&a==size()){
            int iteration = 2;
            Node move = front;
            while(iteration<size()){
               move = move.getNext();
               iteration++;
            }
            move.setNext(move.getNext().getNext());
         }
         else{
            i++;
            while(curr.getNext()!=null){
               if(curr.getData().getLastName().equalsIgnoreCase(s)||curr.getData().getFirstName().equalsIgnoreCase(s)){
                  if(a==i){
                     curr.setNext(curr.getNext().getNext());
                  }
                  i++;
               }
               curr = curr.getNext();
            }
         }
         System.out.println();
      }      
      else if(n==2){
         while (curr!=null){
             if(curr.getData().getStreetName().equalsIgnoreCase(s)){ 
                System.out.println(counter+". "+curr);
                counter++;
             } 
             curr = curr.getNext();
         }
         System.out.print("\nEntry to delete: ");
         int a = kb.nextInt();
         int i = 1;
         curr = front;
         if(front.getData().getStreetName().equalsIgnoreCase(s)&&a==i){
            front = front.getNext();
         }
         else if(last.getData().getStreetName().equalsIgnoreCase(s)&&a==size()){
            int iteration = 2;
            Node move = front;
            while(iteration<size()){
               move = move.getNext();
               iteration++;
            }
            move.setNext(move.getNext().getNext());
         }
         else{
            i++;
            while(curr.getNext()!=null){
               if(curr.getNext().getData().getStreetName().equalsIgnoreCase(s)){
                  if(a==i){
                     curr.setNext(curr.getNext().getNext());
                  }
                  i++;
               }
               curr = curr.getNext();
            }
         }
         System.out.println();
      }
      else if(n==3){
        while (curr!=null){
             if(curr.getData().getPhone().contains(s)){ 
                System.out.println(counter+". "+curr);
                counter++;
             } 
             curr = curr.getNext();
         }
         System.out.print("\nEntry to delete: ");
         int a = kb.nextInt();
         int i = 1;
         curr = front;
         if(front.getData().getPhone().contains(s)&&a==i){
            front = front.getNext();
         }
         else if(last.getData().getPhone().contains(s)&&a==size()){
            int iteration = 2;
            Node move = front;
            while(iteration<size()){
               move = move.getNext();
               iteration++;
            }
            move.setNext(move.getNext().getNext());
         }
         else{
            i++;
            while(curr.getNext()!=null){
               if(curr.getNext().getData().getPhone().contains(s)){
                  if(a==i){
                     curr.setNext(curr.getNext().getNext());
                  }
                  i++;
               }
               curr = curr.getNext();
            }
         }
         System.out.println();
      }
   }
} 