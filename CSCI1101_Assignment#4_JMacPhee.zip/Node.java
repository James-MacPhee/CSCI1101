/*CSCI 1101 - Assignment #4 - Node
  
  This program simply defines the common 'Node' object

  James MacPhee - B00768516 - April.4th/2018 */
public class Node{ 
   
   private Contact data;
   private Node next;
   //Constructor
   public Node(Contact c, Node n){ 
      data = c; 
      next = n; 
   }
   // --- Get and Set Methods --- 
   public Contact getData(){
      return data;
   } 
   public Node getNext(){
      return next;
   }
   public void setData(Contact d){
      data = d;
   }
   public void setNext(Node n){
      next = n;
   }
   //toString method to improve readability
   public String toString(){ 
      return data.toString(); 
  } 
} 
