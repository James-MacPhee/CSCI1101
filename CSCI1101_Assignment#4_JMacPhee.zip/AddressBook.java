/*CSCI 1101 - Assignment #4 - AddressBook
  
  This program defines an AddressBook that contains 'Contact' object and 
  utilizes the LinkedList class and in turn the Node class to store them.

  James MacPhee - B00768516 - April.4th/2018 */
public class AddressBook{
   private LinkedList list;
   //Constructor that simply initializes the LinkedList
   public AddressBook(){
      list = new LinkedList();
   }
   //Method to create a new Node filled with a Contact to be added to the LinkedList stored in the AddressBook
   public void addContact(Contact c){
      list.add(c);
   }
   //Method to remove a Node filled with a Contact to be added to the LinkedList stored in the AddressBook
   public void remove(String s, int n){
      list.remove(s,n);
   }
   //Method to retrieve LinkedList
   public LinkedList getList(){
      return list;
   }
   //Method that enables user to look-up a certain Contact in the AddressBook by one of three categories 
   public void search(String s, int n){
      System.out.printf("%n%-20s%-20s%s%n","Name","Street","Phone");
      list.search(s,n);
   }
   //Method that prints out each and every contact stored in LinkedList according to Contact toString method
   public void displayAllContacts(){
      System.out.printf("%n%-20s%-20s%s%n","Name","Street","Phone");
      list.display();
   }
   
}