/*CSCI 1101 - Assignment #4 - Contact
  
  This program defines a single contact that would be found in an 'AddressBook'.

  James MacPhee - B00768516 - April.4th/2018 */
public class Contact{

   private String lastName;
	private String firstName;
	private String streetName;
	private String phone;
   //Constructor that set all attributes
   public Contact(String last,String first,String street,String phone){
      lastName = last;
      firstName = first;
      streetName = street;
      this.phone = phone;
   }
   //An equals method to compare to two 'Contacts'
   public boolean equals(Contact c){
      if(this.firstName==c.getFirstName()&&this.lastName==c.getLastName()&&this.streetName==c.getStreetName()&&this.phone==c.getPhone()) return true;
      else return false;
   }
   // --- Get and Set Methods ---
   public void setLastName(String last){
      lastName = last;
   }
   public String getLastName(){
      return lastName;
   }
   public void setFirstName(String first){
     firstName = first;
   }
   public String getFirstName(){
      return firstName;
   }
   public void setStreetName(String street){
      streetName = street;
   }
   public String getStreetName(){
      return streetName;
   }
   public void setPhone(String phone){
      this.phone = phone;
   }
   public String getPhone(){
      return phone;
   }
   public String toString(){
      return String.format("%-20s%-20s%s",lastName+", "+firstName,streetName,phone);
   }
}