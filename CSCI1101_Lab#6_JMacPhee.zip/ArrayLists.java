/*CSCI 1101 - Lab #6 - ArrayLists

  This program takes two user-inputted lists of Strings and 
  returns a list of all of the common Strings between the two lists.

  James MacPhee - B00768516 - March.9th/2018 */
import java.util.ArrayList;
import java.util.Scanner;
public class ArrayLists{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      ArrayList<String> list1 = new ArrayList<String>();
      ArrayList<String> list2 = new ArrayList<String>();
      System.out.println("Enter words on one line, end with -1:");
      //Populates 'list1' ArrayList with user inputted words
      String word = kb.next();
      while(!word.equals("-1")){
         list1.add(word);
         word = kb.next();
      }
      System.out.println("Enter words on one line, end with -1:");
      //Populates 'list1' ArrayList with user inputted words
      String word2 = kb.next();
      while(!word2.equals("-1")){
         list2.add(word2);
         word2 = kb.next();
      }
      //Following code segment populates 'list3' ArrayList with the common words in 'list1' and 'list2'
      ArrayList<String> list3 = new ArrayList<String>();
      int length;
      if(list1.size()>list2.size()) length = list1.size();
      else length = list2.size();
      for(int i=0;i<length;i++){
         if(list1.size()>list2.size()){
            if(list2.contains(list1.get(i))){
                  list3.add(list1.get(i));
            }
         }
         else{
            if(list1.contains(list2.get(i))){
               list3.add(list2.get(i));
            }
         }
      }
      //Prints the 'list3' ArrayList elements
      System.out.println("Array List with common Strings:");
      for(int i=0;i<list3.size();i++) {
         System.out.print(list3.get(i)+"\t");
      }
   }
}