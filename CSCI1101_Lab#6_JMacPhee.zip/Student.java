/*CSCI 1101 - Lab #6 - Student

  This program defines a 'Student' type object and gives it two attributes: name and GPA.

  James MacPhee - B00768516 - March.9th/2018 */
public class Student{
   
   private String name;
   private double gradePointAverage;
   
   public Student(String name, double gpa){
      this.name = name;
      if(gpa>4)gradePointAverage = 4;
      else gradePointAverage = gpa;
   }
   public void setName(String name){
      this.name = name;
   }
   public String getName(){
      return name;
   }
   public void setGPA(double gpa){
      if(gpa>4)gradePointAverage = 4;
      else gradePointAverage = gpa;
   }
   public double getGPA(){
      return gradePointAverage;
   }
   public String toString(){
      return "\tName: "+name+"\tGrade Point Average: "+gradePointAverage;
   }
}