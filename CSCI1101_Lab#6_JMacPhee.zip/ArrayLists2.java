/*CSCI 1101 - Lab #6 - ArrayLists2

  This program takes a user-inputted list of Strings and 
  returns a list of all of those Strings but without any duplicates.

  James MacPhee - B00768516 - March.9th/2018 */
import java.util.ArrayList;
import java.util.Scanner;
public class ArrayLists2{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      ArrayList<String> list = new ArrayList<String>();
      ArrayList<String> newList = new ArrayList<String>();
      System.out.println("Enter words on one line, end with -1:");
      String word = kb.next();
      //Populates 'list' ArrayList with user inputted words
      while(!word.equals("-1")){ 
         list.add(word);
         word = kb.next();
      }
      //Populates the 'newList' ArrayList with the words from 'list' ArrayList without duplicates
      for(int i=0;i<list.size();i++){
         if(!newList.contains(list.get(i))) newList.add(list.get(i));
      }
      //Prints out the newList ArrayList
      System.out.println("Array list with no duplicates:");
      for(int i=0;i<newList.size();i++){
         System.out.print(newList.get(i)+"\t");
      }
   }
}