/*CSCI 1101 - Lab #6 - StudentDemo

  This program creates an object of type 'Student' and then creates 
  two ArrayLists of students sorting them by different parameters, 
  all based on user-inputted information on each 'Student'. 

  James MacPhee - B00768516 - March.9th/2018 */
import java.util.ArrayList;
import java.util.Scanner;
public class StudentDemo{
   public static void main(String[] args){
   
      ArrayList<Student> students = new ArrayList<Student>();
      Scanner kb = new Scanner(System.in);
      System.out.print("Enter Student name or quit: ");
      String name = kb.next();
      int counter = 0;
      while(!name.equals("quit")){
         if(counter>0){
            System.out.print("\nEnter Student name or quit: ");
            name = kb.next();
         }
         if(!name.equals("quit")){
            System.out.print("Enter grade point average: ");
            Student kid = new Student(name,kb.nextDouble());
            if(counter>0){
               for(int i=0;i<counter;i++){
                  if(kid.getName().compareTo(students.get(i).getName())<0) 
                     students.add(i,kid);
               }
            }
            else students.add(kid);
         }
         counter++;
      }
      System.out.println("\nStudents:");
      for(int i=0;i<students.size();i++){
         System.out.print(students.get(i));
      }
      ArrayList<Student> newStudents = sortGPA(students);
      System.out.println("\nStudents in order of Grade Point Average:");
      for(int i=0;i<counter;i++){ 
         System.out.print(newStudents.get(i));
      }
   }
   
   public static ArrayList<Student> sortGPA(ArrayList<Student> list){
      ArrayList<Student> newStudents = new ArrayList<Student>();
      for(int i=0;i<list.size();i++){
         if(i>0){
            if(list.get(i).getGPA()>newStudents.get(i).getGPA()){ 
               newStudents.add(i,list.get(i));
            }
            else newStudents.add(list.get(i));
         }
         else newStudents.add(
         list.get(i));
      }
      return newStudents;
   }
}