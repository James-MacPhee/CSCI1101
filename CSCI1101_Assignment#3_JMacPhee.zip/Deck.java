/*CSCI 1101 - Assignment #3 - Deck 
  
  This program utilizes the Card class and 
  creates a standard deck of 52 Card objects

  James MacPhee - B00768516 - March.16th/2018 */
import java.util.Collections;
import java.util.Random;
import java.util.ArrayList;
public class Deck{
   
   private ArrayList<Card> deck = new ArrayList<Card>();
   //Constructor that uses 'Card' constructor to create 52 different cards and stores them in an ArrayList
   public Deck(){
      for(int i=0;i<4;i++){
         for(int j=1;j<14;j++){
            if(i==0){
               Card c = new Card("Hearts",j);
               deck.add(c);
            }
            if(i==1){
               Card c = new Card("Diamond",j);
               deck.add(c);
            }
            if(i==2){
               Card c = new Card("Spades",j);
               deck.add(c);
            }
            if(i==3){
               Card c = new Card("Clubs",j);
               deck.add(c);
            }
         }   
      }
   }
   // --- Get and Set Methods ---
   public void setDeck(ArrayList<Card> deck){
      this.deck = deck;
   }
   public ArrayList<Card> getDeck(){
      return deck;
   }
   //Method to shuffle/randomize the deck of cards
   public void shuffle(){
      Collections.shuffle(deck);
   }
}