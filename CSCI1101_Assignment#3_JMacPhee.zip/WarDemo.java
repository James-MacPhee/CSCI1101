/*CSCI 1101 - Assignment #3 - WarDemo 
  
  This program utilizes the Deck and Card classes to create 
  an automated version of the popular card game "War".

  James MacPhee - B00768516 - March.16th/2018 */
import java.util.ArrayList;
import java.util.Scanner;
public class WarDemo{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      System.out.println("Welcome to WAR! Let's Play!\n");
      System.out.println("Enter the first player's name: ");
      String name1 = kb.next();
      System.out.println("Enter the second player's name: ");
      String name2 = kb.next();
      Deck deck = new Deck();
      deck.shuffle();
      ArrayList<Card> deck1 = new ArrayList<Card>();
      ArrayList<Card> deck2 = new ArrayList<Card>();
      for(int i=0;i<26;i++){
         deck1.add(deck.getDeck().get(i));
      }
      for(int i=26;i<52;i++){
         deck2.add(deck.getDeck().get(i));
      }
      System.out.printf("%-5s#Cards\t\t%-5s#Cards",name1,name2,"Winner");
      System.out.println();
      int counter1 = 0;
      int counter2 = 0;
      while(!deck1.isEmpty()||deck2.isEmpty()){
         if(deck1.get(counter1).getValue()>deck2.get(counter2).getValue()){
            System.out.printf("%-5s%5s%5s%5s",deck1.get(counter1),deck1.size(),deck2.get(counter2),deck2.size(),name1);
            System.out.println();
            deck1.add(deck2.get(counter2));
            deck2.remove(counter2);
         }
         else if(deck1.get(counter1).getValue()<deck2.get(counter2).getValue()){
            System.out.printf("%-5s%5s%5s%5s",deck1.get(counter1),deck1.size(),deck2.get(counter2),deck2.size(),name2);
            System.out.println();
            deck2.add(deck1.get(counter1));
            deck1.remove(counter1);
         }
         else{
            while(deck1.get(counter1).getValue()==deck2.get(counter2).getValue()){
               ArrayList<Card> temp = new ArrayList<Card>();
               System.out.println("************************************WAR***********************************");
               System.out.printf("%-5s%5s%5s%5s",deck1.get(counter1),deck1.size(),deck2.get(counter2),deck2.size(),"WAR");
               System.out.println();
               System.out.println("**********************************END WAR*********************************");
               counter1++;
               counter2++;
               for(int i=0;i<=counter1;i++){
                  temp.add(deck1.get(i));
               }
               for(int i=0;i<=counter2;i++){
                  temp.add(deck2.get(i));
               }
            }
            if(deck1.get(counter1).getValue()>deck2.get(counter2).getValue()){
               System.out.printf("%-5s%5s%5s%5s",deck1.get(counter1),deck1.size(),deck2.get(counter2),deck2.size(),name1);
               System.out.println();
               deck1.add(deck2.get(counter2));
               deck2.remove(counter2);
            }
            else{
               System.out.printf("%-5s%5s%5s%5s",deck1.get(counter1),deck1.size(),deck2.get(counter2),deck2.size(),name1);
               System.out.println();
               deck1.add(deck2.get(counter2));
               deck2.remove(counter2);
            }
         } 
         counter1++;
         counter2++;
      }
      if(deck1.isEmpty()) System.out.println(name1+"Wins! Congratulations");
      else System.out.println(name2+"Wins! Congratulations");
      System.out.println("Play Again (y/n)? ");
   }
}