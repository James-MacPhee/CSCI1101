/*CSCI 1101 - Assignment #3 - Card
  
  This program defines a card object that has one 
  of four suits, a value between 1 and 13, and a given rank.

  James MacPhee - B00768516 - March.16th/2018 */
public class Card{

   private String suit;
   private String rank;
   private int value;
   //Constructor that sets suit and value to given parameters and determines correct rank based on value
   public Card(String suit, int value){
      this.suit = suit;
      this.value = value;
      if(value<11&&value>1) rank=Integer.toString(value);
      else if(value==1) rank="Ace";
      else if(value==11) rank="Jack";
      else if(value==12) rank="Queen";
      else if(value==13) rank="King";
   }
   // --- Get and Set Methods ---
   public void setSuit(String suit){
      this.suit = suit;
   }
   public String getSuit(){
      return suit;
   }
   public void setRank(String rank){
      this.rank = rank;
   }
   public String getRank(){
      return rank;
   }
   public void setValue(int value){
      this.value = value;
   }
   public int getValue(){
      return value;
   }
   //toString method to improve readability
   public String toString(){
      return value+" "+suit;
   }
}