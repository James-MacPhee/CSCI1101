/*CSCI 1101 - Lab #5 - Dictionary

  This program defines a Book object which simply has one attribute: number of pages.

  James MacPhee - B00768516 - March.2nd/2018 */
public class Book{

   private int numPages;
   //Constructor that sets number of pages
   public Book(int n){
      numPages = n;
   }
   public int getPages(){
      return numPages;
   }
   public void setPages(int n){
      numPages = n;
   }
   //toString method to improve readability
   public String toString(){
      return "Number of pages: "+numPages;
   }
}