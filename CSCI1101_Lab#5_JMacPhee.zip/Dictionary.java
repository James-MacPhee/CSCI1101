/*CSCI 1101 - Lab #5 - Dictionary

  This program defines a dictionary object which is of type 'Book'

  James MacPhee - B00768516 - March.2nd/2018 */
public class Dictionary extends Book{

   private int numDefinitions;
   //Constructor that uses the constructor of a 'Book'
   public Dictionary(int p, int d){
      super(p);
      numDefinitions = d;
   }
   public int getDefinitions(){
      return numDefinitions;
   }
   public void setDefinitions(int n){
      numDefinitions = n;
   }
   /* Method to compute ratio of number of definitions compared to number of pages
      This method is created in accordance with the UML diagram but would not actually 
      compute a ratio if it was used because it uses integer division */
   public int computeRatio(){
      return numDefinitions/super.getPages();
   }
   //toString method to improve readability
   public String toString(){
      return super.toString()+"\tNumber of definitions: "+numDefinitions;
   }
}
