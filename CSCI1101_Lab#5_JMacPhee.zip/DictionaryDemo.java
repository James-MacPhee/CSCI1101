/*CSCI 1101 - Lab #5 - DictionaryDemo

  This program creates a 'Dictionary' object 
  (in turn creating a 'Book' type object) and prints it's information.

  James MacPhee - B00768516 - March.2nd/2018 */
public class DictionaryDemo{
   public static void main(String[] args){
      
      Dictionary dict = new Dictionary(12, 400);
      System.out.println(dict);
   }
}