/*CSCI 1101 - Lab #5 - ExaggeratingKid

  This program defines an ExaggeratingKid object which is of type 'SchoolKid'.

  James MacPhee - B00768516 - March.2nd/2018 */
public class ExaggeratingKid extends SchoolKid{
   //Constructor that creates and modifies the super's (SchoolKid) constructor
   public ExaggeratingKid(int age, String name, String teachName, String greeting){
      super(age+2,name,teachName,greeting+" I am the best.");
   }
   //getAge method that modifies the super class's getAge method
   public int getAge(){
      return super.getAge()+2;
   }
   //getGreeting method that modifies the super class's getGreeting method
   public String getGreeting(){
      return super.getGreeting()+" I am the best.";
   }
}