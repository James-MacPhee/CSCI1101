/*CSCI 1101 - Lab #5 - ExaggeratingKidDemo

  This program creates an 'ExggeratingKid' and prints it's information.

  James MacPhee - B00768516 - March.2nd/2018 */
public class ExaggeratingKidDemo{
   public static void main(String[] args){
   
      ExaggeratingKid kid1 = new ExaggeratingKid(14, "Bobbie", "Duck", "Wassup?");
      System.out.println(kid1);
   }
}