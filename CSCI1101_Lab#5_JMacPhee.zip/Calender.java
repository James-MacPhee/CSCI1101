/*CSCI 1101 - Lab #5 - Calender

  This program takes in creates a common 7-day week calender for a month that the user specifies.

  James MacPhee - B00768516 - March.2nd/2018 */
import java.util.Scanner;
public class Calender{
   public static void main(String[] args){
      
      Scanner kb = new Scanner(System.in);
      //Creates 2D array to hold the days of the month
      int[][] cal = new int[6][7];
      System.out.print("Enter the name of the month: ");
      String month = kb.next();   //Input
      System.out.print("What day is the first of the month: ");
      String startDay = kb.next();   //Input
      System.out.print("How many days are in this month: ");
      int days = kb.nextInt();   //Input
      System.out.println("\n"+month+"\n\nSun\tMon\tTue\tWed\tThu\tFri\tSat");
      int j;
      //'If else' statements to determine which day the calender should start on
      if(startDay.equalsIgnoreCase("sunday")) j=0;
      else if(startDay.equalsIgnoreCase("monday")) j=1;
      else if(startDay.equals("tuesday")) j=2;
      else if(startDay.equals("wednesday")) j=3;
      else if(startDay.equals("thursday")) j=4;
      else if(startDay.equals("friday")) j=5;
      else j=6;
      int count=1;
      //'for' loop to populate the 2D array with the values of days of the month
      for(int i=0;i<6;i++){
         while(j<7){
            if(count<=days) cal[i][j] = count;
            j++;
            count++;
         }
         j=0;
      }
      count=1;
      //'for' loop to print out the values stored in the 2D array (days of the month)
      for(int i=0;i<6;i++){
         for(j=0;j<7;j++){
            if(cal[i][j]!=0){
               if(count<=days) System.out.print(cal[i][j]+"\t\t");
               count++;
            }
            else System.out.print("\t\t");
         }
         System.out.println();
      }
   }
}