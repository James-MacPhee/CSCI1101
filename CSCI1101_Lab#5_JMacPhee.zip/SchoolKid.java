/*CSCI 1101 - Lab #5 - SchoolKid

  This program defines a SchoolKid object that has the attributes of name, age, a greeting, and a teacher's name.

  James MacPhee - B00768516 - March.2nd/2018 */
public class SchoolKid{

   private int age;
   private String name;
   private String teachName;
   private String greeting;
   //Constructor that sets the attributes
   public SchoolKid(int age, String name, String teachName, String greeting){
      this.age = age;
      this.name = name;
      this.teachName = teachName;
      this.greeting = greeting;
   }
   // --- get and Set methods ---
   public int getAge(){
      return age;
   }
   public void setAge(int age){
      this.age = age;
   }
   public String getName(){
      return name;
   }
   public void setName(String name){
      this.name = name;
   }
   public String getTeachName(){
      return teachName;
   }
   public void setTeachName(String teachName){
      this.teachName = teachName;
   }
   public String getGreeting(){
      return greeting;
   }
   public void setGreeting(String greeting){
      this.greeting = greeting;;
   }
   //toString method to improve readability
   public String toString(){
      return "Name: "+name+"\tAge: "+age+"\tTeacher's Name: "+teachName+"\tGreeting: "+greeting;
   }   
}