/*CSCI 1101 - Lab #8 - ElasticLines
  
  This program lets a user draw lines of user-selected colours on a simple background

  James MacPhee - B00768516 - April.6th/2018 */
import javafx.application.Application;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

public class ElasticLines extends Application{
    private Line line;
    private Group root;
 
    @Override
    public void start(Stage primaryStage) {
        root = new Group();
        //Creating buttons, setting size, and giving actions
        Button btnR = new Button("Black");
        btnR.setLayoutX(100);
        btnR.setPrefSize(75,10);
        btnR.setOnAction(this::btnRPressed);
        Button btnB = new Button("Cyan");
        btnB.setLayoutX(175);
        btnB.setPrefSize(75,10);
        btnB.setOnAction(this::btnBPressed);
        Button btnG = new Button("White");
        btnG.setLayoutX(250);
        btnG.setPrefSize(75,10);
        btnG.setOnAction(this::btnGPressed);
        Button btnP = new Button("Red");
        btnP.setLayoutX(325);
        btnP.setPrefSize(75,10);
        btnP.setOnAction(this::btnPPressed);
        //Adding buttons
        root.getChildren().add(btnR);
        root.getChildren().add(btnB);
        root.getChildren().add(btnG);
        root.getChildren().add(btnP);
        //Creating Scene
        Scene scene = new Scene(root, 500, 500,Color.LIGHTBLUE);
        scene.setOnMousePressed(this::processMousePress);    
        scene.setOnMouseDragged(this::processMouseDrag);
        //Setting stage
        primaryStage.setTitle("Elastic Lines");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    //Red button pressed action
    public void btnRPressed(ActionEvent e){
       line.setStroke(Color.BLACK);
    }
    //Blue button pressed action
    public void btnBPressed(ActionEvent e){
       line.setStroke(Color.CYAN);
    }
    //Green button pressed action
    public void btnGPressed(ActionEvent e){
       line.setStroke(Color.WHITE);
    }
    //Purple button pressed action
    public void btnPPressed(ActionEvent e){
       line.setStroke(Color.RED);
    }
    //Mouse press action
    public void processMousePress(MouseEvent e){
        line = new Line(e.getX(), e.getY(), e.getX(), e.getY());
        line.setStroke(Color.RED);
        line.setStrokeWidth(3);
        root.getChildren().add(line);
    }
    //Mouse drag action
    public void processMouseDrag(MouseEvent e){
        line.setEndX(e.getX());
        line.setEndY(e.getY());
    }
    //Main method
    public static void main(String[] args) {
        Application.launch(args);
    }
 }