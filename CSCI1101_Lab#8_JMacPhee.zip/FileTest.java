/* CSCI 1101 - Lab #8 - Filetest
  
   This program takes a file that includes the name (first name last name)
   of a certain number of students and their four lab marks (out of 10). 
   It then creates a new file that includes the students name (last name, first name)
   and each students average lab mark plus the total class average.
   James MacPhee - B00768516 - April.6th/2018 */
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;

public class FileTest{
   public static void main(String[] args) throws Exception{
      //creating used variables
      String firstName;
      String lastName;
      double mark1;
      double mark2;
      double mark3;
      double mark4;
      int count = 0;
      double ave = 0;
      double classAve = 0;
      //Creating input Scanner and output PrintWriter
      Scanner sc = new Scanner(new File("C:/Users/james/OneDrive/Documents/JGrasp/CSCI1101_Lab#8_JMacPhee/Input3.txt"));
      PrintWriter pw = new PrintWriter(new File("C:/Users/james/OneDrive/Documents/JGrasp/CSCI1101_Lab#8_JMacPhee/Output3.txt"));
      
      pw.printf("%-20s%s%n%n","Name","Ave. Lab Mark");
      //while loop to iterate through each line of input file
      while(sc.hasNext()){
         firstName = sc.next();
         lastName = sc.next();
         mark1 = sc.nextDouble();
         mark2 = sc.nextDouble();
         mark3 = sc.nextDouble();
         mark4 = sc.nextDouble();
         ave = (mark1+mark2+mark3+mark4)/4;
         classAve += ave;
         pw.printf("%-20s%.2f%n",lastName+", "+firstName,ave);
         count++;
      }
      classAve = classAve/count;
      pw.printf("\nTotal Students: %d\t\t\tAverage Lab Mark: %.2f",count,classAve);
      //Closing streams
      sc.close();
      pw.close();
   }
}